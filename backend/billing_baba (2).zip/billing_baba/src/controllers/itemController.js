const Item = require('../models/Item');
const Product = require('../models/Product');

exports.createItem = async (req, res) => {
    try {
        const { type, name, companyId, ...details } = req.body;

        // Common base for Item
        const itemData = {
            companyId,
            type,
            name
        };

        if (type === 'product') {
            // 1. Create Product Document
            const productData = { ...details, companyId };
            if (productData.openingQuantity && productData.currentQuantity === undefined) {
                productData.currentQuantity = productData.openingQuantity;
            }

            const product = new Product(productData);
            const savedProduct = await product.save();

            // 2. Link to Item
            itemData.product = savedProduct._id;

            // Sync common fields to Item for easier access and consistency
            Object.assign(itemData, {
                unit: details.unit,
                category: details.category,
                itemCode: details.itemCode,
                images: details.images,
                salePrice: details.salePrice,
                purchasePrice: details.purchasePrice,
                discount: details.discount,
                taxRate: details.taxRate
            });

            const item = new Item(itemData);
            await item.save();

            // Return full structure
            const fullItem = await Item.findById(item._id).populate('product');
            res.status(201).json(fullItem);

        } else if (type === 'service') {
            // 1. Save details directly to Item
            // Map 'hsn' to 'sac' if needed
            if (details.hsn) itemData.sac = details.hsn;
            if (details.sac) itemData.sac = details.sac;

            // Copy other fields
            Object.assign(itemData, {
                unit: details.unit,
                category: details.category,
                itemCode: details.itemCode,
                images: details.images,
                salePrice: details.salePrice,
                purchasePrice: details.purchasePrice,
                discount: details.discount,
                taxRate: details.taxRate
            });

            const item = new Item(itemData);
            await item.save();
            res.status(201).json(item);

        } else {
            return res.status(400).json({ error: 'Invalid item type' });
        }

    } catch (error) {
        console.error(error);
        res.status(400).json({ error: error.message });
    }
};

exports.getItems = async (req, res) => {
    try {
        const { companyId, type, productId } = req.query;
        const filter = {};
        if (companyId) filter.companyId = companyId;
        if (type) filter.type = type;
        if (productId) filter.product = productId;

        const items = await Item.find(filter).populate('product');
        res.json(items);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.getItemById = async (req, res) => {
    try {
        const item = await Item.findById(req.params.id).populate('product');
        if (!item) return res.status(404).json({ message: 'Item not found' });
        res.json(item);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.updateItem = async (req, res) => {
    try {
        const { name, ...details } = req.body;

        const item = await Item.findById(req.params.id);
        if (!item) return res.status(404).json({ message: 'Item not found' });

        if (name) item.name = name;

        if (item.type === 'product' && item.product) {
            // Update linked Product
            await Product.findByIdAndUpdate(item.product, details);

            // Sync Item wrapper fields
            item.set({
                unit: details.unit,
                category: details.category,
                itemCode: details.itemCode,
                images: details.images,
                salePrice: details.salePrice,
                purchasePrice: details.purchasePrice,
                discount: details.discount,
                taxRate: details.taxRate
            });

            await item.save();
        } else if (item.type === 'service') {
            // Update Item fields directly
            if (details.hsn) details.sac = details.hsn;

            item.set(details);
            await item.save();
        }

        const updatedItem = await Item.findById(req.params.id).populate('product');
        res.json(updatedItem);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

exports.deleteItem = async (req, res) => {
    try {
        const item = await Item.findById(req.params.id);
        if (!item) return res.status(404).json({ message: 'Item not found' });

        if (item.type === 'product' && item.product) {
            await Product.findByIdAndDelete(item.product);
        }
        // No Service model to delete, just the Item

        await Item.findByIdAndDelete(req.params.id);
        res.json({ message: 'Item deleted' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};
