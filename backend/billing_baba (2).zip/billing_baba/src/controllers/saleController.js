const Sale = require('../models/Sale');
const Item = require('../models/Item');
const Product = require('../models/Product');
const Party = require('../models/Party');

const createSale = async (req, res) => {
    const session = await Sale.startSession();
    session.startTransaction();
    try {
        const saleData = req.body;

        // Auto-set isInvoice based on documentType
        if (saleData.documentType === 'SO') {
            saleData.isInvoice = false;
            saleData.isOrder = true; // Mark as Order
            saleData.isPaid = false; // Open
        } else {
            saleData.documentType = 'INVOICE';
            saleData.isInvoice = true;
            saleData.isOrder = false;
            saleData.isPaid = true; // Treated as "Paid" or Active Invoice
        }



        const sale = new Sale(saleData);

        // --- Auto-Generate Numbers ---
        if (sale.documentType === 'INVOICE' && !sale.invoiceNumber) {
            const lastInvoice = await Sale.findOne({
                companyId: sale.companyId,
                documentType: 'INVOICE'
            }).sort({ createdAt: -1 });

            let nextNum = 1;
            if (lastInvoice && lastInvoice.invoiceNumber) {
                const parts = lastInvoice.invoiceNumber.split('-');
                const lastNum = parseInt(parts[parts.length - 1]);
                if (!isNaN(lastNum)) nextNum = lastNum + 1;
            }
            sale.invoiceNumber = `INV-${nextNum}`;
        }

        if (sale.documentType === 'SO' && !sale.orderNumber) {
            const lastOrder = await Sale.findOne({
                companyId: sale.companyId,
                documentType: 'SO'
            }).sort({ createdAt: -1 });

            let nextNum = 1;
            if (lastOrder && lastOrder.orderNumber) {
                const parts = lastOrder.orderNumber.split('-');
                const lastNum = parseInt(parts[parts.length - 1]);
                if (!isNaN(lastNum)) nextNum = lastNum + 1;
            }
            sale.orderNumber = `ORD-${nextNum}`;

            // "add isOrder on orders": 
            // Although schema has isInvoice, we can explicitly set this if user requested, 
            // but Mongoose schema is strict by default. 
            // We'll rely on generating orderNumber as the primary interpretation.
        }

        await sale.save({ session });

        // --- EFFECT LOGIC ---
        // Only affect Inventory and Accounts if it is an INVOICE (not an Order)
        if (sale.isInvoice) {

            // 1. Update Stock
            if (sale.items && sale.items.length > 0) {
                for (const lineItem of sale.items) {
                    if (lineItem.itemId) {
                        const itemDoc = await Item.findById(lineItem.itemId).session(session);

                        // Only update stock if it's a Product
                        if (itemDoc && itemDoc.type === 'product' && itemDoc.product) {
                            const qty = Number(lineItem.quantity);

                            // If Sale: Decrease Stock
                            // If Return: Increase Stock
                            const change = sale.isReturn ? qty : -qty;

                            await Product.findByIdAndUpdate(
                                itemDoc.product,
                                { $inc: { 'currentQuantity': change } },
                                { session }
                            );
                        }
                    }
                }
            }

            // 2. Update Party Balance
            if (sale.partyId) {
                const amount = sale.balanceDue;
                if (amount !== 0) {
                    // If Sale: Increase Receivable (+ve)
                    // If Return: Decrease Receivable (-ve)
                    const balanceChange = sale.isReturn ? -amount : amount;

                    await Party.findByIdAndUpdate(
                        sale.partyId,
                        { $inc: { currentBalance: balanceChange } },
                        { session }
                    );
                }
            }
        }

        await session.commitTransaction();
        session.endSession();

        res.status(201).json(sale);
    } catch (error) {
        await session.abortTransaction();
        session.endSession();
        console.error("Sale Create Error:", error);
        res.status(400).json({ error: error.message });
    }
}
const getSales = async (req, res) => {
    try {
        const { companyId, partyId, startDate, endDate, type, isReturn, status } = req.query;
        const filter = {};

        if (companyId) filter.companyId = companyId;
        if (partyId) filter.partyId = partyId;

        if (type === 'SO') {
            // "Sales Orders" list:
            // Show if it is an Order (Open) OR a Converted Order (Invoice with isOrder=true)
            filter.$or = [
                { isOrder: true },             // Modern Flag
                { documentType: 'SO' },        // Legacy/Fallback
                { orderNumber: { $exists: true, $ne: "" }, documentType: 'INVOICE' } // Legacy converted
            ];
        } else if (type === 'INVOICE') {
            // "Sale Invoices" list: 
            // Show Invoices that are NOT Orders.
            filter.documentType = 'INVOICE';
            filter.isOrder = { $ne: true };
        } else if (type) {
            filter.documentType = type;
        }

        // ... (inside convertToInvoice function further down, I need to match the StartLine/EndLine or do a separate block if they are far apart. They are in same file.)

        // Wait, replace_file_content works on contiguous blocks. getSales is ~122-160. convertToInvoice is ~185+. 
        // I will start with getSales block.

        if (isReturn !== undefined) filter.isReturn = isReturn === 'true';

        // Filter by Date (check both invoiceDate and orderDate)
        if (startDate && endDate) {
            filter.$or = [
                { invoiceDate: { $gte: new Date(startDate), $lte: new Date(endDate) } },
                { orderDate: { $gte: new Date(startDate), $lte: new Date(endDate) } }
            ];
        }

        const sales = await Sale.find(filter)
            .populate('partyId', 'name phone')
            .sort({ createdAt: -1 });

        res.json(sales);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

const getSaleById = async (req, res) => {
    try {
        const sale = await Sale.findById(req.params.id)
            .populate('partyId')
            .populate('items.itemId', 'name type');

        if (!sale) return res.status(404).json({ message: 'Sale not found' });
        res.json(sale);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// Convert Sale Order to Invoice (Update existing document)
const convertToInvoice = async (req, res) => {
    const session = await Sale.startSession();
    session.startTransaction();
    try {
        const soId = req.params.id;
        const so = await Sale.findById(soId).session(session);
        if (!so || so.documentType !== 'SO') {
            throw new Error("Invalid Sale Order");
        }

        // Update fields to make it an Invoice
        so.documentType = 'INVOICE';
        so.isInvoice = true;
        so.isOrder = true; // Ensure it remains flagged as an Order (Converted)
        so.invoiceNumber = req.body.invoiceNumber || so.orderNumber || `INV-${Date.now()}`; // Use order number or generate new
        so.invoiceDate = new Date();
        so.isPaid = true; // Mark as Paid/Converted

        await so.save({ session });

        // Apply Effects (Stock/Party) now that it is an Invoice
        if (so.items && so.items.length > 0) {
            for (const lineItem of so.items) {
                if (lineItem.itemId) {
                    const itemDoc = await Item.findById(lineItem.itemId).session(session);
                    if (itemDoc && itemDoc.type === 'product' && itemDoc.product) {
                        const qty = Number(lineItem.quantity);
                        // Sale Invoice: Decrease Stock
                        await Product.findByIdAndUpdate(
                            itemDoc.product,
                            { $inc: { 'currentQuantity': -qty } },
                            { session }
                        );
                    }
                }
            }
        }

        if (so.partyId) {
            const amount = so.balanceDue;
            if (amount !== 0) {
                // Sale Invoice: Increase Receivable
                await Party.findByIdAndUpdate(
                    so.partyId,
                    { $inc: { currentBalance: amount } },
                    { session }
                );
            }
        }

        await session.commitTransaction();
        session.endSession();
        res.status(200).json(so);

    } catch (error) {
        await session.abortTransaction();
        session.endSession();
        res.status(400).json({ error: error.message });
    }
};

const updateSale = async (req, res) => {
    // Note: This does NOT yet handle reverting/re-applying stock logic for edits.
    try {
        const sale = await Sale.findByIdAndUpdate(req.params.id, req.body, { new: true });
        res.json(sale);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const processReturn = async (req, res) => {
    const session = await Sale.startSession();
    session.startTransaction();
    try {
        const saleId = req.params.id;
        const { items: returnItems, ...otherDetails } = req.body; // Allow overriding items for partial return

        const originalSale = await Sale.findById(saleId).session(session);
        if (!originalSale) {
            throw new Error("Original Sale not found");
        }

        // Prepare Return Data
        const returnData = {
            ...originalSale.toObject(),
            ...otherDetails
        };

        delete returnData._id;
        delete returnData.createdAt;
        delete returnData.updatedAt;

        // Force Return Flags
        returnData.isReturn = true;
        returnData.isInvoice = true; // Returns are accounting documents
        returnData.isPaid = true;
        returnData.documentType = 'INVOICE';
        returnData.originalSaleId = originalSale._id;

        // Generate Return Number if not provided
        if (!returnData.invoiceNumber.startsWith('RET-')) {
            returnData.invoiceNumber = `RET-${originalSale.invoiceNumber}`;
        }

        // If specific items provided for return, use them. Otherwise default to full return of original items.
        // NOTE: If partial return, caller must recalculate totals (subTotal, grandTotal, etc) and send them in body.
        if (returnItems && returnItems.length > 0) {
            returnData.items = returnItems;
        }

        const returnSale = new Sale(returnData);
        await returnSale.save({ session });

        // --- EFFECT LOGIC For Return ---
        // 1. Stock: Increase (Items coming back)
        if (returnSale.items && returnSale.items.length > 0) {
            for (const lineItem of returnSale.items) {
                if (lineItem.itemId) {
                    const itemDoc = await Item.findById(lineItem.itemId).session(session);
                    if (itemDoc && itemDoc.type === 'product' && itemDoc.product) {
                        const qty = Number(lineItem.quantity);
                        // Return -> Increase Stock
                        await Product.findByIdAndUpdate(
                            itemDoc.product,
                            { $inc: { 'currentQuantity': qty } },
                            { session }
                        );
                    }
                }
            }
        }

        // 2. Party Balance: Decrease Payable/Receivable
        // For Sale Return: We owe the customer (or they owe us less).
        // Current Balance is Receivable (+ve). So we reduce it (-ve).
        if (returnSale.partyId) {
            const amount = returnSale.balanceDue; // The amount being returned/credited
            if (amount !== 0) {
                await Party.findByIdAndUpdate(
                    returnSale.partyId,
                    { $inc: { currentBalance: -amount } },
                    { session }
                );
            }
        }

        await session.commitTransaction();
        session.endSession();
        res.status(201).json(returnSale);

    } catch (error) {
        await session.abortTransaction();
        session.endSession();
        res.status(400).json({ error: error.message });
    }
};
module.exports = {
    createSale,
    getSales,
    getSaleById,
    updateSale,
    convertToInvoice,
    processReturn
}