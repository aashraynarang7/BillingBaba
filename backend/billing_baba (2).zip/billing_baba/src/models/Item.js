const mongoose = require('mongoose');

const itemSchema = new mongoose.Schema({
    companyId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Company',
        required: false
    },
    type: {
        type: String,
        enum: ['product', 'service'],
        required: true
    },
    name: {
        type: String,
        required: true,
        trim: true
    },

    // --- LINK TO PRODUCT REPOSITORY ---
    product: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Product'
    },

    // --- SERVICE / DIRECT FIELDS (Used when type='service') ---
    // Can also be used for common fields if we refactor later, 
    // but for now strictly enabled for Services to replace ServiceModel

    sac: { type: String, trim: true },
    unit: { type: String, default: 'pcs' },
    category: { type: String, trim: true },
    itemCode: { type: String, trim: true },
    images: [{ type: String }],

    salePrice: {
        amount: { type: Number, default: 0 },
        taxType: { type: String, enum: ['withTax', 'withoutTax'], default: 'withoutTax' }
    },
    discount: {
        value: { type: Number, default: 0 },
        type: { type: String, enum: ['percentage', 'amount'], default: 'percentage' }
    },
    purchasePrice: {
        amount: { type: Number, default: 0 },
        taxType: { type: String, enum: ['withTax', 'withoutTax'], default: 'withoutTax' }
    },
    taxRate: { type: Number, default: 0 },

    createdAt: {
        type: Date,
        default: Date.now
    }
});

module.exports = mongoose.model('Item', itemSchema);
